<script language="javascript">
	$(document).ready(function() { 
		$('#mcq_bank_prog_id').on('change', function() {
			$('#mcq_bank_spec_id').val('').trigger('change');
			$('#mcq_topic_id').val('').trigger('change');
			if ($(this).val() != null && $(this).val() != '') {
				$('#spec_id_div').slideDown('slow');
				$('#mcq_bank_prog_id_for_subject').val($('#mcq_bank_prog_id').val());
				var prog_value1 = $('#mcq_bank_prog_id').val();

				if (prog_value1 == 1) {
					$('#mcq_theme').parent().parent().slideUp('slow');
					// new code for subject if fcps1 selected
					data = [];
					data[0] = this; // source field name
					data[1] = 'mcq_bank_spec_id'; // target field
					data[2] = null;
					data[3] = null;
					data[4] = 'rtmc_spec_ids';

					generate_combo_new(data);

					data = [];
					data[0] = null;
					data[1] = 'mcq_bank_subj_id'; // target field
					data[2] = null; // other option
					data[3] = null;
					data[10] = 'mcq_bank_prog_id_for_subject' // source field name
					data[11] = $('#mcq_bank_prog_id_for_subject').val(); // source field value

					generate_combo_new2(data);

					$('#mcq_bank_subj_id').addClass('required');
					$('#mcq_bank_subj_id').parent().parent().slideDown('slow');
					$('#for_paper_dev').show();
				} else {
					$('#mcq_theme').parent().parent().slideDown('slow');

					data = [];
					data[0] = this;
					data[1] = 'mcq_bank_spec_id';
					data[2] = null;
					data[3] = null;

					generate_combo_new(data);

					$('#mcq_bank_subj_id').removeClass('required').slideUp('slow');
					$('#mcq_bank_subj_id').parent().parent().slideUp('slow');
					$('#for_paper_dev').hide();
				}

			} else {
				$('#mcq_topic_id').val('').trigger('change');
				$('#mcq_sub_speciality').val('').trigger('change');

				$('#spec_id_div').slideUp('slow');
				$('#topic_id_div').slideUp('slow');

				$('#mcq_bank_subj_id').removeClass('required').parent().parent().slideUp('slow');
			}
		}); 
	}); 
	
	
	
	//////////////  combo generation functoin /////////////
	// combo generation function
	function generate_combo_new(data){
		source_field  = data[0];
		target_field  = data[1];
		other_option  = data[2];
		default_value = data[3];
		other_value  =  data[4];
		//alert(other_value);

		var dataString = '';
		dataString = dataString +"source_field="+$(source_field).attr('name')+"&"+$(source_field).attr('name')+"="+$(source_field).val()+"";
		dataString = dataString +"&target_field="+target_field;
		if(other_option != null) { dataString = dataString +"&other_option=1"; }
		if(other_value != null) { dataString = dataString +"&other_value="+other_value; }
		
		//alert(dataString);
		// extra variables for query
		if(data[4] != null) {
			for(i=4; i<data.length; i++) {
				dataString = dataString +"&"+data[i]+"="+$('#'+data[i]+'').val()+"";
			}
		}
		//alert(source_field);
		$('#'+target_field+'_loading_temp').remove();
		$('#'+target_field+"_loading").append('<img src="img/ajax-loaders/ajax-loader-1.gif" id="'+target_field+'_loading_temp" />');
		
		$.ajax({
			url: 'fill_combo_box.php',
			type: 'POST',
			dataType: 'json',					
			data: dataString,
			
			success: function(result){
				
					$('#'+target_field).html("");//clear old options
					result = eval(result);
					for (i = 0; i < result.length; i++) {
					  for ( key in result[i] ) {
							$('#'+target_field).get(0).add(new Option(result[i][key],[key]), document.all ? i : null);
					  }
					}
					if (default_value != null) {
						$('#'+target_field).val(default_value);//select default value
					} 
					else {
						$("option:first", target_field).attr( "selected", "selected" );//select first option
					}
					
					$('#'+target_field+'_loading_temp').fadeOut(500);
					$('#'+target_field+'_loading_temp').fadeOut(500, function()	{	$('#'+target_field+'_loading_temp').remove(); });
					$('#'+target_field).css("display","inline");

			}
		});
	}

	//////////////  combo generation functoin /////////////
	// combo generation function
	function generate_combo_new2(data){
		//source_field2  = data[0];
		source_field_name2  = data[10];
		source_field_value2  = data[11];
		
		target_field2  = data[1];
		other_option2  = data[2];
		default_value2 = data[3];

		var dataString = '';
		dataString = dataString +"source_field="+source_field_name2+"&"+source_field_name2+"="+source_field_value2+"";		
		dataString = dataString +"&target_field="+target_field2;
		if(other_option2 != null) { dataString = dataString +"&other_option=1"; }
		// extra variables for query
		if(data[4] != null) {	for(i=4; i<10; i++) {	dataString = dataString +"&"+data[i]+"="+$('#'+data[i]+'').val()+""; } }
		$('#'+target_field2+"_loading").append('<img src="img/ajax-loaders/ajax-loader-1.gif" id="'+target_field2+'_loading_temp" />');
		
		$.ajax({
			url: 'fill_combo_box.php',
			type: 'POST',
			dataType: 'json',					
			data: dataString,
			success: function(result){
					//alert('iqbal');
					$('#'+target_field2).html("");//clear old options
					result = eval(result);
					for (i = 0; i < result.length; i++) {
					  for ( key in result[i] ) {
					  
							if([key] == 'none'){
								$('#'+target_field2).get(0).add(new Option(result[i][key],''), document.all ? i : null);
							}
							else{
								$('#'+target_field2).get(0).add(new Option(result[i][key],[key]), document.all ? i : null);
							}

						  
						  
					  }
					}
					if (default_value2 != null) {  $('#'+target_field2).val(default_value2);	}	// select default value 
					else {	$("option:first", target_field2).attr( "selected", "selected" );	}   // select first option
					
					$('#'+target_field2+'_loading_temp').fadeOut(500);
					$('#'+target_field2+'_loading_temp').fadeOut(500, function()	{	$('#'+target_field2+'_loading_temp').remove(); });
					$('#'+target_field2).css("display","inline");
			}
		});
	}
</script> 