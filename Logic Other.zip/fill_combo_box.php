<?php 
extract($_REQUEST);
switch($source_field){
	case 'menu_parent_id':
		$query = "select * from gb_menu where parent_id = '".$menu_parent_id."'";
		$result = mysql_query($query);

		if(mysql_num_rows($result) > 0 ){
			while($row = mysql_fetch_array($result)) {		$array[] = array($row['id'] => $row['name']);	}
		}
		else{	$array[] = array('none' => 'No child');	}
	break; 
}
echo json_encode( $array );